<link rel="stylesheet" href="<?php echo e(asset('assets/admin/vendors/feather/feather.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/vendors/ti-icons/css/themify-icons.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/vendors/css/vendor.bundle.base.css')); ?>">
<!-- endinject -->
<!-- Plugin css for this page -->
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/vendors/datatables.net-bs4/dataTables.bootstrap4.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/vendors/ti-icons/css/themify-icons.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/vendors/mdi/css/materialdesignicons.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin/js/select.dataTables.min.css')); ?>">
<!-- End plugin css for this page -->
<!-- inject:css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/vertical-layout-light/style.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/admin/css/style.css')); ?>">

<!-- endinject -->
<link rel="shortcut icon" href="<?php echo e(asset('assets/images/logo/logo.png')); ?>" />
<?php /**PATH D:\xampp\htdocs\sigmaticsoft\sigmaticsoft\src\resources\views/admin/layouts/partials/headerStyle.blade.php ENDPATH**/ ?>