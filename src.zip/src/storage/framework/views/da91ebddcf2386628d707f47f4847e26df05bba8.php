<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <header>
        <?php echo $__env->make('website.layouts.navBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        window.addEventListener('scroll', function() {
            var header = document.querySelector('nav');
            header.classList.toggle('sticky', window.scrollY > 100)
        })
    </script>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\sigmaticsoft\sigmaticsoft\src\resources\views/website/layouts/master.blade.php ENDPATH**/ ?>