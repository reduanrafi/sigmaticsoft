<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Admin Dashboard</title>
    <!-- plugins:css -->
    <?php echo $__env->make('admin.layouts.partials.headerStyle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head><?php /**PATH D:\xampp\htdocs\sigmaticsoft\sigmaticsoft\src\resources\views/admin/layouts/partials/header.blade.php ENDPATH**/ ?>