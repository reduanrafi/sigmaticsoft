<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-8 grid-margin stretch-card mx-auto">
        <div class="card rounded">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="card-title font-weight-bold mb-0">Finance: Categories</h4>
                    <div>
                        <a href="<?php echo e(route('finance.index')); ?>" class="btn btn-outline-secondary btn-sm mr-2">Overview</a>
                        <a href="<?php echo e(route('finance.categories.create')); ?>" class="btn btn-gradient-success text-white btn-sm"><i class="mdi mdi-plus"></i> Create Category</a>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Category Name</th>
                                <th>Type</th>
                                <th>Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><strong><?php echo e($cat->name); ?></strong></td>
                                    <td>
                                        <span class="badge badge-<?php echo e($cat->type === 'income' ? 'success' : 'danger'); ?>"><?php echo e(ucfirst($cat->type)); ?></span>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?php echo e($cat->status === 'active' ? 'success' : 'secondary'); ?>"><?php echo e(ucfirst($cat->status)); ?></span>
                                    </td>
                                    <td>
                                        <div class="d-flex justify-content-center">
                                            <a href="<?php echo e(route('finance.categories.edit', $cat->id)); ?>" class="btn btn-sm btn-outline-primary p-1 px-2 mr-2"><i class="mdi mdi-table-edit"></i> Edit</a>
                                            <form action="<?php echo e(route('finance.categories.destroy', $cat->id)); ?>" method="POST" onsubmit="return confirm('Delete this category?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-outline-danger p-1 px-2"><i class="mdi mdi-delete"></i> Delete</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" class="text-center text-muted py-4">No categories created yet.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sigmaticsoft\sigmaticsoft\src\resources\views/admin_portal/finance/categories/index.blade.php ENDPATH**/ ?>