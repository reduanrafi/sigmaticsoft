<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 grid-margin">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="font-weight-bold mb-0">Finance Dashboard</h3>
            <div>
                <a href="<?php echo e(route('finance.transactions.create', ['type' => 'income'])); ?>" class="btn btn-gradient-success text-white btn-sm mr-2"><i class="mdi mdi-plus"></i> Record Income</a>
                <a href="<?php echo e(route('finance.transactions.create', ['type' => 'expense'])); ?>" class="btn btn-gradient-danger text-white btn-sm"><i class="mdi mdi-minus"></i> Record Expense</a>
            </div>
        </div>
    </div>
</div>

<!-- Financial Stats -->
<div class="row">
    <div class="col-md-3 mb-4 stretch-card transparent">
        <div class="card bg-gradient-success text-white">
            <div class="card-body">
                <p class="mb-4 font-weight-bold">Today's Income</p>
                <p class="fs-30 mb-2 font-weight-bold">+<?php echo e(number_format($todayIncome, 2)); ?> ৳</p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4 stretch-card transparent">
        <div class="card bg-gradient-danger text-white">
            <div class="card-body">
                <p class="mb-4 font-weight-bold">Today's Expense</p>
                <p class="fs-30 mb-2 font-weight-bold">-<?php echo e(number_format($todayExpense, 2)); ?> ৳</p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4 stretch-card transparent">
        <div class="card bg-gradient-info text-white">
            <div class="card-body">
                <p class="mb-4 font-weight-bold">This Month's Income</p>
                <p class="fs-30 mb-2 font-weight-bold">+<?php echo e(number_format($monthIncome, 2)); ?> ৳</p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4 stretch-card transparent">
        <div class="card bg-gradient-warning text-white">
            <div class="card-body">
                <p class="mb-4 font-weight-bold">This Month's Expense</p>
                <p class="fs-30 mb-2 font-weight-bold">-<?php echo e(number_format($monthExpense, 2)); ?> ৳</p>
            </div>
        </div>
    </div>
</div>

<!-- Account Balances & Transfer Form -->
<div class="row">
    <!-- Accounts list -->
    <div class="col-md-6 grid-margin stretch-card">
        <div class="card rounded">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="card-title font-weight-bold mb-0">Operational Accounts</h4>
                    <a href="<?php echo e(route('finance.accounts.index')); ?>" class="btn btn-outline-info btn-sm">Configure Accounts</a>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Account Name</th>
                                <th>Type</th>
                                <th class="text-right">Balance</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><strong><?php echo e($acc->name); ?></strong></td>
                                    <td><span class="text-capitalize"><?php echo e(str_replace('_', ' ', $acc->type)); ?></span></td>
                                    <td class="text-right font-weight-bold <?php echo e($acc->balance >= 0 ? 'text-success' : 'text-danger'); ?>">
                                        <?php echo e(number_format($acc->balance, 2)); ?> ৳
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Transfer Funds Form -->
    <div class="col-md-6 grid-margin stretch-card">
        <div class="card rounded border border-info">
            <div class="card-body">
                <h4 class="card-title font-weight-bold text-info mb-3"><i class="mdi mdi-swap-horizontal"></i> Transfer Funds (Inter-Account)</h4>
                
                <form action="<?php echo e(route('finance.transfers.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label for="from_account">Source Account (From)</label>
                            <select name="from_account_id" id="from_account" class="form-control" required>
                                <option value="" disabled selected>Select Source</option>
                                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($acc->id); ?>"><?php echo e($acc->name); ?> (<?php echo e(number_format($acc->balance, 2)); ?> ৳)</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-6 form-group">
                            <label for="to_account">Destination Account (To)</label>
                            <select name="to_account_id" id="to_account" class="form-control" required>
                                <option value="" disabled selected>Select Destination</option>
                                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($acc->id); ?>"><?php echo e($acc->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label for="amount">Transfer Amount (৳)</label>
                            <input type="number" step="0.01" name="amount" id="amount" class="form-control" required placeholder="e.g. 5000">
                        </div>
                        <div class="col-md-6 form-group">
                            <label for="transaction_date">Date</label>
                            <input type="date" name="transaction_date" id="transaction_date" class="form-control" required value="<?php echo e(date('Y-m-d')); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="reference">Reference / Memo</label>
                        <input type="text" name="reference" id="reference" class="form-control" placeholder="e.g. Weekly transfer, ATM deposit code">
                    </div>
                    <button type="submit" class="btn btn-gradient-info text-white w-100 font-weight-bold"><i class="mdi mdi-swap-horizontal"></i> Process Transfer</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Recent Transactions -->
<div class="row">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="card-title font-weight-bold mb-0">Recent Transaction History</h4>
                    <a href="<?php echo e(route('finance.transactions.index')); ?>" class="btn btn-outline-primary btn-sm">View All Transactions</a>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover table-striped">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Account</th>
                                <th>Type</th>
                                <th>Category</th>
                                <th>Client / Project</th>
                                <th>Description / Ref</th>
                                <th class="text-right">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $recentTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($tx->transaction_date->format('d M, Y')); ?></td>
                                    <td><?php echo e($tx->account->name); ?></td>
                                    <td>
                                        <span class="badge badge-<?php echo e($tx->type === 'income' ? 'success' : ($tx->type === 'expense' ? 'danger' : 'info')); ?>">
                                            <?php echo e(ucfirst($tx->type)); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($tx->category->name ?? 'Transfer'); ?></td>
                                    <td>
                                        <?php if($tx->client): ?>
                                            <span class="d-block text-dark font-weight-bold"><?php echo e($tx->client->company_name); ?></span>
                                        <?php endif; ?>
                                        <?php if($tx->project): ?>
                                            <small class="text-muted"><?php echo e($tx->project->name); ?></small>
                                        <?php endif; ?>
                                        <?php if(!$tx->client && !$tx->project): ?>
                                            <span class="text-muted">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($tx->description ?? 'No description'); ?> <br>
                                        <?php if($tx->reference): ?>
                                            <small class="text-muted">Ref: <?php echo e($tx->reference); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-right font-weight-bold <?php echo e($tx->type === 'income' ? 'text-success' : ($tx->type === 'expense' ? 'text-danger' : 'text-dark')); ?>">
                                        <?php echo e($tx->type === 'income' ? '+' : ($tx->type === 'expense' ? '-' : '')); ?><?php echo e(number_format($tx->amount, 2)); ?> ৳
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">No recent financial logs recorded.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sigmaticsoft\sigmaticsoft\src\resources\views/admin_portal/finance/index.blade.php ENDPATH**/ ?>