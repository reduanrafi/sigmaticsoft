<?php $__env->startSection('title', 'Case Study: Centralized Business Management System | Sigmatic Soft'); ?>
<?php $__env->startSection('meta_description', 'Learn how Sigmatic Soft designed a custom business management portal to unify inventory tracking, vendor invoice approvals, and operations logs.'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Header -->
    <div class="py-5 bg-light text-center border-bottom text-start">
        <div class="container py-4">
            <nav aria-label="breadcrumb" class="mb-3">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('website.index')); ?>" class="text-decoration-none">Home</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('case-studies.index')); ?>" class="text-decoration-none">Case Studies</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Centralized Business Portal</li>
                </ol>
            </nav>
            <span class="insight-grid-tag">Business Systems</span>
            <h1 class="display-4 fw-black text-dark mb-2">Centralized Business Management System</h1>
            <p class="lead text-muted" style="max-width: 700px;">
                Unifying customer records, inventory ledgers, and transaction processing into a secure administrative portal.
            </p>
        </div>
    </div>

    <!-- Case Study Body -->
    <div class="container py-5 text-start">
        <div class="row g-5">
            <!-- Left Side - Context & Story -->
            <div class="col-lg-8">
                <!-- 1. Client Context -->
                <h3 class="fw-bold text-dark mb-3">Client Context</h3>
                <p class="text-muted">
                    The client is a growing professional-services and distribution company with multiple operational departments. As transaction volume increased, manual coordination between sales partners, logistics managers, and billing associates became error-prone.
                </p>

                <!-- 2. Existing Environment -->
                <h3 class="fw-bold text-dark mt-4 mb-3">Existing Environment</h3>
                <p class="text-muted">
                    Operations were tracked across Google Sheets spreadsheets, local file servers, and a legacy standalone accounting tool. The team relied on manual email notifications and phone calls to coordinate billing approvals, client updates, and logistics checkouts.
                </p>

                <!-- 3. Business Problem -->
                <h3 class="fw-bold text-dark mt-4 mb-3">Business Problem</h3>
                <p class="text-muted">
                    Relying on spreadsheets created data fragmentation. Different versions of the customer ledger existed, calculations were overwritten by typo errors, and there was zero audit trail showing who changed inventory levels or billing statuses, causing reconciliation gaps.
                </p>

                <!-- 4. Solution -->
                <h3 class="fw-bold text-dark mt-4 mb-3">The Solution</h3>
                <p class="text-muted">
                    Sigmatic Soft engineered a custom <strong>Centralized Business Management Portal</strong>. The portal provides a single database source of truth, automating inventory checks, billing calculations, and client updates under strict user access controls.
                </p>

                <!-- 5. System Architecture -->
                <h3 class="fw-bold text-dark mt-4 mb-3">System Architecture</h3>
                <div class="arch-flowchart text-white my-4">
                    <div class="arch-node">
                        <div class="arch-node-title">Client Portal / Admin Dashboard</div>
                        <div class="arch-node-desc">Custom Bootstrap 5 / PHP Web Interface</div>
                    </div>
                    <div class="arch-arrow"><div class="arch-connector-line"></div></div>
                    <div class="arch-node">
                        <div class="arch-node-title">Application Core (MVC Framework)</div>
                        <div class="arch-node-desc">Eloquent validation rules, auth roles, and logs audit trail</div>
                    </div>
                    <div class="arch-arrow"><div class="arch-connector-line"></div></div>
                    <div class="arch-node">
                        <div class="arch-node-title">Central Database (MySQL)</div>
                        <div class="arch-node-desc">Normalized schemas for users, clients, tasks, and ledgers</div>
                    </div>
                </div>

                <!-- 6. Implementation -->
                <h3 class="fw-bold text-dark mt-4 mb-3">Implementation</h3>
                <p class="text-muted">
                    We designed a relational database schema using MySQL, ensuring transactional integrity. We built roles and permissions mapping so employees only access fields relevant to their jobs. We migrated data from spreadsheets, sanitizing duplicates during import.
                </p>

                <!-- 7. Outcome -->
                <h3 class="fw-bold text-dark mt-4 mb-3">Operational Outcome</h3>
                <p class="text-muted">
                    The portal eliminated manual spreadsheet synchronization errors. The billing department can immediately view task completions, client managers have instant access to task boards, and administrators have a clear audit log of all account modifications.
                </p>

                <!-- 8. Lessons Learned -->
                <h3 class="fw-bold text-dark mt-4 mb-3">Lessons Learned</h3>
                <p class="text-muted">
                    Moving from spreadsheets to a custom database requires strong user role structures. Standardizing input validation fields prevents database pollution and keeps financial records reliable.
                </p>
            </div>

            <!-- Right Side - Specifications & CTA -->
            <div class="col-lg-4">
                <div class="p-4 bg-light rounded border mb-4">
                    <h5 class="fw-bold text-dark mb-3">Project Details</h5>
                    <ul class="list-unstyled mb-0">
                        <li class="mb-2"><strong>Category:</strong> Business Systems</li>
                        <li class="mb-2"><strong>Timeline:</strong> 12 Weeks</li>
                        <li class="mb-2"><strong>Stack:</strong> PHP / Laravel / MySQL / Bootstrap 5</li>
                        <li class="mb-0"><strong>Status:</strong> Live in Production</li>
                    </ul>
                </div>

                <div class="p-4 bg-dark-tech text-white rounded mb-4">
                    <h5 class="text-white mb-3">Key Capabilities Built</h5>
                    <ul class="list-unstyled small opacity-75">
                        <li class="mb-2">&bull; Custom Client & Project Rosters</li>
                        <li class="mb-2">&bull; Interactive Task Management Board</li>
                        <li class="mb-2">&bull; Financial Transaction Audits</li>
                        <li class="mb-0">&bull; Secure File Attachment Vaults</li>
                    </ul>
                </div>

                <div class="p-4 border rounded text-center">
                    <h5 class="fw-bold mb-2 text-dark">Need a Central System?</h5>
                    <p class="small text-muted mb-4">Let's discuss how to consolidate your operations into a secure platform.</p>
                    <a href="<?php echo e(route('website.contact', ['subject' => 'Central System Request'])); ?>" class="btn btn-premium btn-premium-primary w-100">Discuss a Portal Project</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sigmaticsoft\sigmaticsoft\src\resources\views/website/pages/case_studies/centralized_business_management_system.blade.php ENDPATH**/ ?>