<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-10 grid-margin stretch-card mx-auto">
        <div class="card rounded">
            <div class="card-body">
                <h4 class="card-title font-weight-bold mb-4">Your Projects</h4>

                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Project Code</th>
                                <th>Project Name</th>
                                <th>Progress</th>
                                <th>Priority</th>
                                <th>Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><code><?php echo e($p->project_code); ?></code></td>
                                    <td><strong><a href="<?php echo e(route('client.projects.show', $p->id)); ?>"><?php echo e($p->name); ?></a></strong></td>
                                    <td>
                                        <div class="progress" style="height: 10px;">
                                            <div class="progress-bar bg-gradient-green" role="progressbar" style="width: <?php echo e($p->progress); ?>%;" aria-valuenow="<?php echo e($p->progress); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <small class="text-muted d-block mt-1"><?php echo e($p->progress); ?>% completed</small>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?php echo e($p->priority === 'critical' ? 'danger' : ($p->priority === 'high' ? 'warning' : 'secondary')); ?> text-capitalize">
                                            <?php echo e($p->priority); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?php echo e($p->status === 'active' ? 'success' : ($p->status === 'completed' ? 'primary' : 'secondary')); ?> text-capitalize">
                                            <?php echo e(str_replace('_', ' ', $p->status)); ?>

                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('client.projects.show', $p->id)); ?>" class="btn btn-sm btn-outline-primary px-3">View Details</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center text-muted py-4">No projects registered under your profile.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal_client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sigmaticsoft\sigmaticsoft\src\resources\views/client_portal/projects/index.blade.php ENDPATH**/ ?>