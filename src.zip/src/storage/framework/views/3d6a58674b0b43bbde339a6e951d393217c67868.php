<?php $__env->startSection('title', 'Case Study: ' . $caseStudy->title . ' | Sigmatic Soft'); ?>
<?php $__env->startSection('meta_description', $caseStudy->subtitle ?? $caseStudy->excerpt); ?>

<?php $__env->startSection('content'); ?>
    <!-- Header -->
    <div class="py-5 bg-light text-center border-bottom text-start">
        <div class="container py-4">
            <nav aria-label="breadcrumb" class="mb-3">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('website.index')); ?>" class="text-decoration-none">Home</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('case-studies.index')); ?>" class="text-decoration-none">Case Studies</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($caseStudy->tag ?? 'Case Study Detail'); ?></li>
                </ol>
            </nav>
            <span class="insight-grid-tag"><?php echo e($caseStudy->tag ?? $caseStudy->category); ?></span>
            <h1 class="display-4 fw-black text-dark mb-2"><?php echo e($caseStudy->title); ?></h1>
            <?php if($caseStudy->subtitle): ?>
                <p class="lead text-muted" style="max-width: 700px;">
                    <?php echo e($caseStudy->subtitle); ?>

                </p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Case Study Body -->
    <div class="container py-5 text-start">
        <div class="row g-5">
            <!-- Left Side - Context & Story -->
            <div class="col-lg-8">
                <!-- 1. Client Context -->
                <?php if($caseStudy->client_context): ?>
                    <h3 class="fw-bold text-dark mb-3">Client Context</h3>
                    <p class="text-muted">
                        <?php echo nl2br(e($caseStudy->client_context)); ?>

                    </p>
                <?php endif; ?>

                <!-- 2. Existing Environment -->
                <?php if($caseStudy->existing_environment): ?>
                    <h3 class="fw-bold text-dark mt-4 mb-3">Existing Environment</h3>
                    <p class="text-muted">
                        <?php echo nl2br(e($caseStudy->existing_environment)); ?>

                    </p>
                <?php endif; ?>

                <!-- 3. Business Problem -->
                <?php if($caseStudy->business_problem): ?>
                    <h3 class="fw-bold text-dark mt-4 mb-3">Business Problem</h3>
                    <p class="text-muted">
                        <?php echo nl2br(e($caseStudy->business_problem)); ?>

                    </p>
                <?php endif; ?>

                <!-- 4. Solution -->
                <?php if($caseStudy->solution): ?>
                    <h3 class="fw-bold text-dark mt-4 mb-3">The Solution</h3>
                    <p class="text-muted">
                        <?php echo nl2br(e($caseStudy->solution)); ?>

                    </p>
                <?php endif; ?>

                <!-- 5. System Architecture Flowchart -->
                <?php if($caseStudy->node1_title || $caseStudy->node2_title || $caseStudy->node3_title): ?>
                    <h3 class="fw-bold text-dark mt-4 mb-3">System Architecture</h3>
                    <div class="arch-flowchart text-white my-4">
                        <?php if($caseStudy->node1_title): ?>
                            <div class="arch-node">
                                <div class="arch-node-title"><?php echo e($caseStudy->node1_title); ?></div>
                                <div class="arch-node-desc"><?php echo e($caseStudy->node1_desc); ?></div>
                            </div>
                        <?php endif; ?>
                        <?php if($caseStudy->node2_title): ?>
                            <div class="arch-arrow"><div class="arch-connector-line"></div></div>
                            <div class="arch-node">
                                <div class="arch-node-title"><?php echo e($caseStudy->node2_title); ?></div>
                                <div class="arch-node-desc"><?php echo e($caseStudy->node2_desc); ?></div>
                            </div>
                        <?php endif; ?>
                        <?php if($caseStudy->node3_title): ?>
                            <div class="arch-arrow"><div class="arch-connector-line"></div></div>
                            <div class="arch-node">
                                <div class="arch-node-title"><?php echo e($caseStudy->node3_title); ?></div>
                                <div class="arch-node-desc"><?php echo e($caseStudy->node3_desc); ?></div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <!-- 6. Implementation -->
                <?php if($caseStudy->implementation): ?>
                    <h3 class="fw-bold text-dark mt-4 mb-3">Implementation</h3>
                    <p class="text-muted">
                        <?php echo nl2br(e($caseStudy->implementation)); ?>

                    </p>
                <?php endif; ?>

                <!-- 7. Outcome -->
                <?php if($caseStudy->outcome): ?>
                    <h3 class="fw-bold text-dark mt-4 mb-3">Operational Outcome</h3>
                    <p class="text-muted">
                        <?php echo nl2br(e($caseStudy->outcome)); ?>

                    </p>
                <?php endif; ?>

                <!-- 8. Lessons Learned -->
                <?php if($caseStudy->lessons_learned): ?>
                    <h3 class="fw-bold text-dark mt-4 mb-3">Lessons Learned</h3>
                    <p class="text-muted">
                        <?php echo nl2br(e($caseStudy->lessons_learned)); ?>

                    </p>
                <?php endif; ?>
            </div>

            <!-- Right Side - Specifications & CTA -->
            <div class="col-lg-4">
                <div class="p-4 bg-light rounded border mb-4">
                    <h5 class="fw-bold text-dark mb-3">Project Details</h5>
                    <ul class="list-unstyled mb-0">
                        <?php if($caseStudy->category): ?>
                            <li class="mb-2"><strong>Category:</strong> <?php echo e($caseStudy->category); ?></li>
                        <?php endif; ?>
                        <?php if($caseStudy->timeline): ?>
                            <li class="mb-2"><strong>Timeline:</strong> <?php echo e($caseStudy->timeline); ?></li>
                        <?php endif; ?>
                        <?php if($caseStudy->stack): ?>
                            <li class="mb-2"><strong>Stack:</strong> <?php echo e($caseStudy->stack); ?></li>
                        <?php endif; ?>
                        <?php if($caseStudy->status): ?>
                            <li class="mb-0"><strong>Status:</strong> <?php echo e($caseStudy->status); ?></li>
                        <?php endif; ?>
                    </ul>
                </div>

                <?php if($caseStudy->capability_1 || $caseStudy->capability_2 || $caseStudy->capability_3 || $caseStudy->capability_4): ?>
                    <div class="p-4 bg-dark-tech text-white rounded mb-4">
                        <h5 class="text-white mb-3">Capabilities Engineered</h5>
                        <ul class="list-unstyled small opacity-75">
                            <?php if($caseStudy->capability_1): ?>
                                <li class="mb-2">&bull; <?php echo e($caseStudy->capability_1); ?></li>
                            <?php endif; ?>
                            <?php if($caseStudy->capability_2): ?>
                                <li class="mb-2">&bull; <?php echo e($caseStudy->capability_2); ?></li>
                            <?php endif; ?>
                            <?php if($caseStudy->capability_3): ?>
                                <li class="mb-2">&bull; <?php echo e($caseStudy->capability_3); ?></li>
                            <?php endif; ?>
                            <?php if($caseStudy->capability_4): ?>
                                <li class="mb-0">&bull; <?php echo e($caseStudy->capability_4); ?></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if($caseStudy->cta_title): ?>
                    <div class="p-4 border rounded text-center">
                        <h5 class="fw-bold mb-2 text-dark"><?php echo e($caseStudy->cta_title); ?></h5>
                        <?php if($caseStudy->cta_description): ?>
                            <p class="small text-muted mb-4"><?php echo e($caseStudy->cta_description); ?></p>
                        <?php endif; ?>
                        <a href="<?php echo e($caseStudy->cta_link ?? route('website.contact')); ?>" class="btn btn-premium btn-premium-primary w-100">
                            <?php echo e($caseStudy->cta_button_text ?? 'Discuss Your Project'); ?>

                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sigmaticsoft\sigmaticsoft\src\resources\views/website/pages/case_studies/show.blade.php ENDPATH**/ ?>