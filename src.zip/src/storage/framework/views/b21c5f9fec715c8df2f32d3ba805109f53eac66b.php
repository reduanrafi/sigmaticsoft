<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-7 grid-margin stretch-card mx-auto">
        <div class="card rounded">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="card-title font-weight-bold mb-0 <?php echo e($type === 'income' ? 'text-success' : 'text-danger'); ?>">
                        Record <?php echo e(ucfirst($type)); ?> Transaction
                    </h4>
                    <a href="<?php echo e(route('finance.transactions.index')); ?>" class="btn btn-outline-secondary btn-sm"><i class="mdi mdi-arrow-left"></i> Back</a>
                </div>

                <form action="<?php echo e(route('finance.transactions.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="type" value="<?php echo e($type); ?>">

                    <div class="form-group">
                        <label for="account_id">Select Asset Account <span class="text-danger">*</span></label>
                        <select name="account_id" id="account_id" class="form-control" required>
                            <option value="" disabled selected>Select Account</option>
                            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($acc->id); ?>"><?php echo e($acc->name); ?> (Balance: <?php echo e(number_format($acc->balance, 2)); ?> ৳)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="category_id">Select Category <span class="text-danger">*</span></label>
                        <select name="category_id" id="category_id" class="form-control" required>
                            <option value="" disabled selected>Select Category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="amount">Transaction Amount (৳) <span class="text-danger">*</span></label>
                        <input type="number" step="0.01" name="amount" id="amount" class="form-control" required placeholder="0.00">
                    </div>

                    <div class="form-group">
                        <label for="transaction_date">Transaction Date <span class="text-danger">*</span></label>
                        <input type="date" name="transaction_date" id="transaction_date" class="form-control" required value="<?php echo e(date('Y-m-d')); ?>">
                    </div>

                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label for="client_id">Associate Client Company <span class="text-muted">(Optional)</span></label>
                            <select name="client_id" id="client_id" class="form-control">
                                <option value="">None / Not Applicable</option>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($c->id); ?>"><?php echo e($c->company_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-6 form-group">
                            <label for="project_id">Associate Project <span class="text-muted">(Optional)</span></label>
                            <select name="project_id" id="project_id" class="form-control">
                                <option value="">None / Not Applicable</option>
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?> (<?php echo e($p->client->company_name); ?>)</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="reference">Reference / Memo</label>
                        <input type="text" name="reference" id="reference" class="form-control" placeholder="e.g. Invoice #214, Domain renewal code">
                    </div>

                    <div class="form-group">
                        <label for="description">Transaction Description</label>
                        <textarea name="description" id="description" class="form-control" rows="3" placeholder="Write transaction details here..."></textarea>
                    </div>

                    <button type="submit" class="btn btn-gradient-<?php echo e($type === 'income' ? 'success' : 'danger'); ?> text-white w-100 mt-3 font-weight-bold">
                        Save <?php echo e(ucfirst($type)); ?> Entry
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sigmaticsoft\sigmaticsoft\src\resources\views/admin_portal/finance/transactions/create.blade.php ENDPATH**/ ?>