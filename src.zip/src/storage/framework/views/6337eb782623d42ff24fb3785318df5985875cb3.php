
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card rounded">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <h4 class="card-title">Produts</h4>
                    <a href="<?php echo e(route('products.create')); ?>"
                        class="btn btn-outline-success btn-sm rounded d-flex align-items-center"><i
                            class="mdi mdi-plus mr-1"></i>
                        Create</a>
                </div>
                <div class="table-responsive pt-3">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>
                                    SL
                                </th>
                                <th class="text-center">
                                    Image
                                </th>
                                <th>
                                    Name
                                </th>
                                <th>
                                    Slug
                                </th>
                                <th>
                                    Price
                                </th>
                                <th>
                                    Stock
                                </th>
                                <th>
                                    Discount
                                </th>
                                <th>
                                    Status
                                </th>
                                <th class="text-center">
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td align="center">
                                    <img src="<?php echo e(asset($product->featured_image)); ?>" width="50" height="50">
                                </td>
                                <td><?php echo e($product->name); ?></td>
                                <td><?php echo e($product->slug); ?></td>
                                <td><?php echo e($product->price); ?></td>
                                <td><?php echo e($product->quantity); ?></td>
                                <td><?php echo e($product->discount); ?></td>
                                <td><?php echo e($product->is_active==1? 'Active':'Inactive'); ?></td>
                                <td>
                                    <div class="d-flex justify-content-center">
                                        <a href="<?php echo e(route('products.edit', $product->id)); ?>"
                                            class="btn btn-sm btn-outline-primary rounded-0 p-1"><i
                                                class="mdi mdi-table-edit"></i></a>
                                        <form action="<?php echo e(route('products.destroy', $product->id )); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit"
                                                class="btn btn-sm btn-outline-danger rounded-0 p-1 ml-2"><i
                                                    class="mdi mdi-delete"></i></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center text-danger">Please Add Products First</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sigmaticsoft\sigmaticsoft\src\resources\views/admin/pages/products/index.blade.php ENDPATH**/ ?>