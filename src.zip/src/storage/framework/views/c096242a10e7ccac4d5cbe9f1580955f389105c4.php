<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Task Details Card -->
    <div class="col-md-4 mb-4">
        <div class="card rounded">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="card-title font-weight-bold mb-0">Task Specifications</h4>
                    <a href="<?php echo e(route('client.projects.show', $task->project_id)); ?>" class="btn btn-outline-secondary btn-sm"><i class="mdi mdi-arrow-left"></i> Back</a>
                </div>

                <ul class="list-group list-group-flush mb-4">
                    <li class="list-group-item py-3">
                        <small class="text-muted d-block">Task Code</small>
                        <span class="font-weight-bold text-dark"><code><?php echo e($task->task_code); ?></code></span>
                    </li>
                    <li class="list-group-item py-3">
                        <small class="text-muted d-block">Title</small>
                        <span class="font-weight-bold text-dark fs-14"><?php echo e($task->title); ?></span>
                    </li>
                    <li class="list-group-item py-3">
                        <small class="text-muted d-block">Project Name</small>
                        <a href="<?php echo e(route('client.projects.show', $task->project_id)); ?>" class="font-weight-bold text-info"><?php echo e($task->project->name); ?></a>
                    </li>
                    <li class="list-group-item py-3">
                        <small class="text-muted d-block">Type</small>
                        <span class="badge badge-outline-dark text-capitalize"><?php echo e($task->type); ?></span>
                    </li>
                    <li class="list-group-item py-3">
                        <small class="text-muted d-block">Priority</small>
                        <span class="badge badge-<?php echo e($task->priority === 'critical' ? 'danger' : ($task->priority === 'high' ? 'warning' : 'secondary')); ?> text-capitalize"><?php echo e($task->priority); ?></span>
                    </li>
                    <li class="list-group-item py-3">
                        <small class="text-muted d-block">Current Status</small>
                        <span class="badge badge-<?php echo e($task->status === 'completed' ? 'success' : ($task->status === 'in_progress' ? 'info' : 'secondary')); ?> text-capitalize"><?php echo e(str_replace('_', ' ', $task->status)); ?></span>
                    </li>
                    <li class="list-group-item py-3">
                        <small class="text-muted d-block">Due Date</small>
                        <span class="text-dark font-weight-bold"><?php echo e($task->due_date ? $task->due_date->format('d M, Y') : 'N/A'); ?></span>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Description & Conversation Feed -->
    <div class="col-md-8">
        <!-- Description -->
        <div class="card rounded mb-4">
            <div class="card-body">
                <h4 class="card-title font-weight-bold mb-3">Task Details</h4>
                <div class="text-dark p-3 bg-light rounded" style="min-height: 100px;">
                    <?php echo $task->description ?? '<span class="text-muted">No description provided for this task.</span>'; ?>

                </div>
            </div>
        </div>

        <!-- Task Attachments -->
        <div class="card rounded mb-4">
            <div class="card-body">
                <h5 class="font-weight-bold mb-3"><i class="mdi mdi-paperclip"></i> Task Attachments</h5>
                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $task->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-sm-6 mb-3">
                            <div class="p-2 border rounded d-flex justify-content-between align-items-center bg-light">
                                <span class="text-dark text-truncate mr-2" style="font-size: 12px; max-width: 180px;" title="<?php echo e($attach->file_name); ?>"><?php echo e($attach->file_name); ?></span>
                                <a href="<?php echo e(route('attachments.download', $attach->id)); ?>" class="btn btn-sm btn-outline-primary p-1 px-2" title="Download"><i class="mdi mdi-download"></i></a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12">
                            <p class="text-muted mb-0">No attachments uploaded directly on this task.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Discussion Feed -->
        <div class="card rounded">
            <div class="card-body">
                <h4 class="card-title font-weight-bold mb-4">Conversation Feed</h4>
                
                <div class="comment-feed mb-4" style="max-height: 400px; overflow-y: auto; padding-right: 10px;">
                    <?php $__empty_1 = true; $__currentLoopData = $task->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="p-3 border rounded mb-3 bg-light">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <div>
                                    <strong class="text-dark"><?php echo e($comment->user->name); ?></strong>
                                    <?php if($comment->user->isClient()): ?>
                                        <span class="badge badge-info ml-1">Client Contact</span>
                                    <?php else: ?>
                                        <span class="badge badge-primary ml-1">Sigmatic Team</span>
                                    <?php endif; ?>
                                </div>
                                <small class="text-muted"><?php echo e($comment->created_at->diffForHumans()); ?></small>
                            </div>
                            <p class="text-dark mb-2" style="white-space: pre-line;"><?php echo e($comment->body); ?></p>

                            <!-- Comment Attachments -->
                            <?php if($comment->attachments->count() > 0): ?>
                                <div class="border-top pt-2 mt-2">
                                    <div class="d-flex flex-wrap">
                                        <?php $__currentLoopData = $comment->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cAttach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="mr-2 mb-2 p-1 px-2 border rounded bg-white d-flex align-items-center">
                                                <small class="text-dark text-truncate mr-2" style="max-width: 150px;"><?php echo e($cAttach->file_name); ?></small>
                                                <a href="<?php echo e(route('attachments.download', $cAttach->id)); ?>" class="text-success mr-2" title="Download"><i class="mdi mdi-download"></i></a>
                                                <?php if($cAttach->uploaded_by === auth()->id()): ?>
                                                    <form action="<?php echo e(route('attachments.destroy', $cAttach->id)); ?>" method="POST" onsubmit="return confirm('Delete comment attachment?')">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="border-0 bg-transparent text-danger p-0"><i class="mdi mdi-close"></i></button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-muted text-center py-4">No comments posted yet. Leave a question or feedback below.</p>
                    <?php endif; ?>
                </div>

                <!-- Add Public Comment Form -->
                <h5 class="font-weight-bold mb-3 text-primary">Add a Comment</h5>
                <form action="<?php echo e(route('client.tasks.comments.store', $task->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <textarea name="body" class="form-control" rows="3" required placeholder="Ask a question or leave comments on progress..."></textarea>
                    </div>
                    <div class="form-group">
                        <label for="c_attachments">Upload Attachments (Optional, Max 5MB)</label>
                        <input type="file" name="attachments[]" id="c_attachments" class="form-control-file" multiple>
                    </div>
                    <button type="submit" class="btn btn-gradient-blue text-white w-100"><i class="mdi mdi-send"></i> Submit Comment</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal_client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sigmaticsoft\sigmaticsoft\src\resources\views/client_portal/tasks/show.blade.php ENDPATH**/ ?>