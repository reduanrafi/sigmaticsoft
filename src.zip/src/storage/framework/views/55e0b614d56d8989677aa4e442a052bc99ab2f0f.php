
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card rounded">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <h4 class="card-title">Product Create</h4>
                    <div>
                        <a href="<?php echo e(route('products.index')); ?>"
                            class="btn btn-outline-success btn-sm rounded d-flex align-items-center"><i
                                class="mdi mdi-eye mr-1"></i> View All</a>
                    </div>
                </div>
                <div class="col-md-offset-2 mt-2" id="messageDiv">
                    <?php if(Session::has('success')): ?>
                    <?php echo $__env->make('admin.layouts.message.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php elseif(Session::has('error')): ?>
                    <?php echo $__env->make('admin.layouts.message.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                </div>
                <form action="<?php echo e(route("products.store")); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Name</label>
                        <div class="input-group">
                            <input type="text" name="name" class="form-control" placeholder="Write Product Name"
                                required>
                        </div>
                        <!-- /.input group -->
                    </div>
                    <div class="form-group">
                        <label for="description">Description</label>
                        <div class="input-group">
                            <textarea type="text" name="description"
                                      id="editor"
                                      class="form-control"
                                placeholder="Write Product Description" rows="5" cols="20"></textarea>
                        </div>
                        <!-- /.input group -->
                    </div>
                    <div class="form-group">
                        <label>Featured Image</label>
                        <div class="input-group">
                            <input type="file" name="featured_image" id="featured_image" class="form-control">
                        </div>
                        <p class="mt-2"><img class="rounded" id="imageOutput" width="200" /></p>
                        <!-- /.input group -->
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Price</label>
                                <div class="input-group">
                                    <input type="number" name="price" class="form-control"
                                        placeholder="Write Product Price">
                                </div>
                                <!-- /.input group -->
                            </div>
                            <div class="form-group">
                                <label for="unit">Unit</label>
                                <div class="input-group">
                                    <input type="text" name="unit" class="form-control"
                                        placeholder="Write Product Unit">
                                </div>
                                <!-- /.input group -->
                            </div>
                            <div class="form-group">
                                <label for="vat_percent">Vat Percent</label>
                                <div class="input-group">
                                    <input type="text" name="vat_percent" class="form-control"
                                        placeholder="Write Product Total Vat Percent">
                                </div>
                                <!-- /.input group -->
                            </div>
                            <div class="form-group">
                                <label for="is_sold_out">Out Of Stock</label>
                                <select class="form-control" name="is_sold_out" id="is_sold_out">
                                    <option disabled label="Please Select" selected></option>
                                    <option value="1">Yes</option>
                                    <option value="0">No</option>
                                </select>
                                <!-- /.input group -->
                            </div>
                            <div class="form-group">
                                <label>Select Category</label>
                                <div class="input-group">
                                    <select class="form-control" name="category_id" id="">
                                        <option disabled label="Please Select" selected></option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="quantity">Quantity</label>
                                <div class="input-group">
                                    <input type="number" name="quantity" class="form-control"
                                        placeholder="Write Product Quantity">
                                </div>
                            </div>
                            <!-- /.input group -->
                            <div class="form-group">
                                <label for="sold_amount">Total Sold</label>
                                <div class="input-group">
                                    <input type="text" name="sold_amount" class="form-control"
                                        placeholder="Write Product Total Sold Amount">
                                </div>
                                <!-- /.input group -->
                            </div>
                            <div class="form-group">
                                <label for="discount">Discount</label>
                                <div class="input-group">
                                    <input type="text" name="discount" class="form-control"
                                        placeholder="Write Product Total Vat Percent">
                                </div>
                                <!-- /.input group -->
                            </div>
                            <div class="form-group">
                                <label for="is_featured">Featured</label>
                                <select class="form-control" name="is_featured" id="is_featured">
                                    <option disabled label="Please Select" selected></option>
                                    <option value="1">Yes</option>
                                    <option value="0">No</option>
                                </select>
                                <!-- /.input group -->
                            </div>
                            <div class="form-group">
                                <label for="is_active">Status</label>
                                <select class="form-control" name="is_active" id="is_active">
                                    <option disabled label="Please Select" selected></option>
                                    <option value="1">Active</option>
                                    <option value="0">Inactive</option>
                                </select>
                                <!-- /.input group -->
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="text-center">
                                <button class="btn btn-outline-success rounded mt-2 w-50"> <i
                                        class="fa-solid fa-save"></i>
                                    Submit
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
    <!-- Summernote JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#editor').summernote();
        });
    </script>
<script>
    const featureImage = document.getElementById('featured_image');
    featureImage.onchange = evt => {
        const [file] = featureImage.files
        if (file) {
        imageOutput.src = URL.createObjectURL(file)
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sigmaticsoft\sigmaticsoft\src\resources\views/admin/pages/products/create.blade.php ENDPATH**/ ?>