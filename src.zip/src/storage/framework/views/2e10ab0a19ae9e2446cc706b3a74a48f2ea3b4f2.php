
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card rounded">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h4 class="card-title">insight Create</h4>
                        <div>
                            <a href="<?php echo e(route('insight.index')); ?>"
                                class="btn btn-outline-success btn-sm rounded d-flex align-items-center"><i
                                    class="mdi mdi-eye mr-1"></i> View All</a>
                        </div>
                    </div>
                    <div class="col-md-offset-2 mt-2" id="messageDiv">
                        <?php if(Session::has('success')): ?>
                            <?php echo $__env->make('admin.layouts.message.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif(Session::has('error')): ?>
                            <?php echo $__env->make('admin.layouts.message.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>
                    </div>
                    <form action="<?php echo e(route('insight.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Insight title</label>
                            <div class="input-group">
                                <input type="text" name="title" class="form-control" placeholder="Write insight Name">
                            </div>
                            <!-- /.input group -->
                        </div>
                        <div class="form-group">
                            <label>Insight excerpt</label>
                            <div class="input-group">
                                <input type="text" name="excerpt" class="form-control" placeholder="Write insight excerpt">
                            </div>
                            <!-- /.input group -->
                        </div>
                        <div class="form-group">
                            <label>Meta title</label>
                            <div class="input-group">
                                <div class="input-group">
                                    <input type="text" name="meta_title" class="form-control" placeholder="Write insight Name">
                                </div>




                            </div>
                            <!-- /.input group -->
                        </div>
                        <div class="form-group">
                            <label>Meta Keywords</label>
                            <div class="input-group">
                                <textarea class="w-100 form-control" name="meta_keywords"
                                          rows="10" placeholder="Write description about insight">

                                </textarea>
                            </div>
                            <!-- /.input group -->
                        </div>
                        <div class="form-group">
                            <label>Meta Description</label>
                            <div class="input-group">
                                <textarea class="w-100 form-control" name="meta_description" id=""
                                          rows="10" placeholder="Write description about insight">

                                </textarea>
                            </div>
                            <!-- /.input group -->
                        </div>

                        <div class="form-group">
                            <label>insight Description</label>
                            <div class="input-group">
                                <textarea class="w-100 form-control" name="content" id="editor"
                                          rows="10" placeholder="Write description about insight">

                                </textarea>
                            </div>
                            <!-- /.input group -->
                        </div>
                        <div class="form-group">
                            <label>insight image</label>
                            <div class="input-group">
                                <input type="file" name="featured_image" id="featured_image" class="form-control">
                            </div>
                            <p class="mt-2"><img class="rounded" id="imageOutput" width="200" /></p>
                            <!-- /.input group -->
                        </div>
                        <div class="form-group">
                            <label>Status</label>
                            <div class="input-group">
                                <select name="is_active" class="form-control">
                                        <option label="Please Select"></option>
                                        <option value="1">Active</option>
                                        <option value="0">inactive</option>
                                </select>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mr-2">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

    <script>
        const imageUpload = document.getElementById('featured_image');
        imageUpload.onchange = evt => {
            const [file] = imageUpload.files
            if (file) {
                const imageOutput = document.getElementById('imageOutput');
                imageOutput.src = URL.createObjectURL(file)
            }
        }
    </script>
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.9.0/dist/summernote-bs4.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.9.0/dist/summernote-bs4.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#editor').summernote({
                height: 300,
                placeholder: 'Write description about insight...'
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sigmaticsoft\sigmaticsoft\src\resources\views/admin/pages/insights/create.blade.php ENDPATH**/ ?>