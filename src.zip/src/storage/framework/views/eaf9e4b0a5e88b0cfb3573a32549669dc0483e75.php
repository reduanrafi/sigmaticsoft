<?php $__env->startSection('title', 'Case Study: Legacy PHP to Laravel Modernization | Sigmatic Soft'); ?>
<?php $__env->startSection('meta_description', 'Read how Sigmatic Soft upgraded an unmaintained PHP code architecture, refactored database tables, and configured safe deployment staging.'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Header -->
    <div class="py-5 bg-light text-center border-bottom text-start">
        <div class="container py-4">
            <nav aria-label="breadcrumb" class="mb-3">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('website.index')); ?>" class="text-decoration-none">Home</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('case-studies.index')); ?>" class="text-decoration-none">Case Studies</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Legacy Modernization</li>
                </ol>
            </nav>
            <span class="insight-grid-tag">Modernization</span>
            <h1 class="display-4 fw-black text-dark mb-2">Legacy PHP to Laravel Upgrade</h1>
            <p class="lead text-muted" style="max-width: 700px;">
                Modernizing an outdated core business database, refactoring old codebase scripts, and deploying secure cloud staging environments.
            </p>
        </div>
    </div>

    <!-- Case Study Body -->
    <div class="container py-5 text-start">
        <div class="row g-5">
            <!-- Left Side - Context & Story -->
            <div class="col-lg-8">
                <!-- 1. Client Context -->
                <h3 class="fw-bold text-dark mb-3">Client Context</h3>
                <p class="text-muted">
                    The client operates a retail management network using a custom-built PHP system designed in 2015. The software runs critical billing calculations, inventory logs, and customer invoicing data.
                </p>

                <!-- 2. Existing Environment -->
                <h3 class="fw-bold text-dark mt-4 mb-3">Existing Environment</h3>
                <p class="text-muted">
                    The system ran on an outdated PHP 5.6 web server, using unstructured, spaghetti code scripts with raw SQL database queries, and had zero test coverage. The site sat on shared web hosting with minimal firewall protections.
                </p>

                <!-- 3. Business Problem -->
                <h3 class="fw-bold text-dark mt-4 mb-3">Business Problem</h3>
                <p class="text-muted">
                    The local hosting provider deprecated PHP 5.6 support, forcing database security upgrade parameters. The custom code was highly fragile: adding new features often caused unexpected billing crashes, and deployments required manual FTP code uploads, introducing database corruption risks.
                </p>

                <!-- 4. Solution -->
                <h3 class="fw-bold text-dark mt-4 mb-3">The Solution</h3>
                <p class="text-muted">
                    Sigmatic Soft modernized the application code structure. We refactored raw queries into a clean Laravel MVC architecture, secured database credentials, and migrated the production server to a secure containerized environment.
                </p>

                <!-- 5. System Architecture -->
                <h3 class="fw-bold text-dark mt-4 mb-3">System Architecture</h3>
                <div class="arch-flowchart text-white my-4">
                    <div class="arch-node">
                        <div class="arch-node-title">Spaghetti Code scripts & raw SQL</div>
                        <div class="arch-node-desc">Fragile PHP 5.6 codebases with vulnerability exposures</div>
                    </div>
                    <div class="arch-arrow"><div class="arch-connector-line"></div></div>
                    <div class="arch-node">
                        <div class="arch-node-title">Laravel Refactoring MVC (Upgrade)</div>
                        <div class="arch-node-desc">Eloquent ORM validation, PHP 8.2 upgrade, & unit testing</div>
                    </div>
                    <div class="arch-arrow"><div class="arch-connector-line"></div></div>
                    <div class="arch-node">
                        <div class="arch-node-title">Secure Cloud Hosting (VPC)</div>
                        <div class="arch-node-desc">Containerized Docker instances with database firewall blocks</div>
                    </div>
                </div>

                <!-- 6. Implementation -->
                <h3 class="fw-bold text-dark mt-4 mb-3">Implementation</h3>
                <p class="text-muted">
                    We built integration tests representing the core checkout processes first. We refactored legacy SQL statements into clean Eloquent models, separated environment variables using dotenv files, and configured automated Github Action pipelines to deploy changes to Docker staging before production rollout.
                </p>

                <!-- 7. Outcome -->
                <h3 class="fw-bold text-dark mt-4 mb-3">Operational Outcome</h3>
                <p class="text-muted">
                    The application response latency dropped significantly. Core transactional databases are fully secure, automated testing covers critical user checkout routines, and deployments are executed with zero downtime.
                </p>

                <!-- 8. Lessons Learned -->
                <h3 class="fw-bold text-dark mt-4 mb-3">Lessons Learned</h3>
                <p class="text-muted">
                    Modernizing legacy software incrementally is always safer than a full rewrite. Standardizing environment configurations using containers ensures local testing mirrors production, preventing post-launch regression bugs.
                </p>
            </div>

            <!-- Right Side - Specifications & CTA -->
            <div class="col-lg-4">
                <div class="p-4 bg-light rounded border mb-4">
                    <h5 class="fw-bold text-dark mb-3">Project Details</h5>
                    <ul class="list-unstyled mb-0">
                        <li class="mb-2"><strong>Category:</strong> Legacy Modernization</li>
                        <li class="mb-2"><strong>Timeline:</strong> 14 Weeks</li>
                        <li class="mb-2"><strong>Stack:</strong> PHP / Laravel / Docker / MySQL / Git</li>
                        <li class="mb-0"><strong>Status:</strong> Live in Production</li>
                    </ul>
                </div>

                <div class="p-4 bg-dark-tech text-white rounded mb-4">
                    <h5 class="text-white mb-3">Capabilities Engineered</h5>
                    <ul class="list-unstyled small opacity-75">
                        <li class="mb-2">&bull; Laravel MVC code refactoring</li>
                        <li class="mb-2">&bull; PostgreSQL/MySQL schema upgrade</li>
                        <li class="mb-2">&bull; Github Actions deployment CI/CD</li>
                        <li class="mb-0">&bull; Containerized Docker hosting</li>
                    </ul>
                </div>

                <div class="p-4 border rounded text-center">
                    <h5 class="fw-bold mb-2 text-dark">Have Legacy Software?</h5>
                    <p class="small text-muted mb-4">Let's audit your old code and design a safe, incremental upgrade path.</p>
                    <a href="<?php echo e(route('services.software-audit')); ?>" class="btn btn-premium btn-premium-primary w-100">Request a Systems Audit</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sigmaticsoft\sigmaticsoft\src\resources\views/website/pages/case_studies/legacy_modernization_demonstration.blade.php ENDPATH**/ ?>