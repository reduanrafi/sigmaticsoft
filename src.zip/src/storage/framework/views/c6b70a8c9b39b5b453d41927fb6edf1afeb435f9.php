<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card rounded">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="card-title font-weight-bold mb-0">Tasks List</h4>
                    <div>
                        <a href="<?php echo e(route('tasks.board')); ?>" class="btn btn-gradient-info text-white btn-sm mr-2"><i class="mdi mdi-view-week"></i> Kanban Board</a>
                        <a href="<?php echo e(route('tasks.create')); ?>" class="btn btn-gradient-success text-white btn-sm"><i class="mdi mdi-plus"></i> Create Task</a>
                    </div>
                </div>

                <!-- Filters -->
                <form action="<?php echo e(route('tasks.index')); ?>" method="GET" class="mb-4">
                    <div class="row">
                        <div class="col-md-3 mb-2">
                            <input type="text" name="search" class="form-control" placeholder="Search task title/code" value="<?php echo e(request('search')); ?>">
                        </div>
                        <div class="col-md-3 mb-2">
                            <select name="project_id" class="form-control">
                                <option value="">Filter by Project</option>
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($p->id); ?>" <?php echo e(request('project_id') == $p->id ? 'selected' : ''); ?>><?php echo e($p->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-2 mb-2">
                            <select name="status" class="form-control">
                                <option value="">Filter by Status</option>
                                <option value="backlog" <?php echo e(request('status') === 'backlog' ? 'selected' : ''); ?>>Backlog</option>
                                <option value="accepted" <?php echo e(request('status') === 'accepted' ? 'selected' : ''); ?>>Accepted</option>
                                <option value="in_progress" <?php echo e(request('status') === 'in_progress' ? 'selected' : ''); ?>>In Progress</option>
                                <option value="review" <?php echo e(request('status') === 'review' ? 'selected' : ''); ?>>Review</option>
                                <option value="client_review" <?php echo e(request('status') === 'client_review' ? 'selected' : ''); ?>>Client Review</option>
                                <option value="completed" <?php echo e(request('status') === 'completed' ? 'selected' : ''); ?>>Completed</option>
                                <option value="rejected" <?php echo e(request('status') === 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                                <option value="cancelled" <?php echo e(request('status') === 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                            </select>
                        </div>
                        <div class="col-md-2 mb-2">
                            <select name="assigned_to" class="form-control">
                                <option value="">Filter by Assignee</option>
                                <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($member->id); ?>" <?php echo e(request('assigned_to') == $member->id ? 'selected' : ''); ?>><?php echo e($member->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-2 mb-2">
                            <button type="submit" class="btn btn-gradient-primary text-white w-100">Filter</button>
                        </div>
                    </div>
                </form>

                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Code</th>
                                <th>Task Title</th>
                                <th>Project</th>
                                <th>Type</th>
                                <th>Priority</th>
                                <th>Assignee</th>
                                <th>Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><code><?php echo e($task->task_code); ?></code></td>
                                    <td>
                                        <strong><a href="<?php echo e(route('tasks.show', $task->id)); ?>"><?php echo e($task->title); ?></a></strong>
                                        <?php if(!$task->client_visible): ?>
                                            <span class="badge badge-warning ml-1" style="font-size: 9px;"><i class="mdi mdi-eye-off"></i> Staff Only</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($task->project->name); ?></td>
                                    <td><span class="text-capitalize"><?php echo e($task->type); ?></span></td>
                                    <td>
                                        <span class="badge badge-<?php echo e($task->priority === 'critical' ? 'danger' : ($task->priority === 'high' ? 'warning' : ($task->priority === 'medium' ? 'info' : 'secondary'))); ?>">
                                            <?php echo e(ucfirst($task->priority)); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($task->assignee->name ?? 'Unassigned'); ?></td>
                                    <td>
                                        <span class="badge badge-<?php echo e($task->status === 'completed' ? 'success' : ($task->status === 'in_progress' ? 'info' : 'secondary')); ?>">
                                            <?php echo e(ucfirst(str_replace('_', ' ', $task->status))); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <div class="d-flex justify-content-center">
                                            <a href="<?php echo e(route('tasks.show', $task->id)); ?>" class="btn btn-sm btn-outline-info p-1 px-2 mr-2"><i class="mdi mdi-eye"></i> View</a>
                                            <a href="<?php echo e(route('tasks.edit', $task->id)); ?>" class="btn btn-sm btn-outline-primary p-1 px-2 mr-2"><i class="mdi mdi-table-edit"></i> Edit</a>
                                            <form action="<?php echo e(route('tasks.destroy', $task->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this task?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-outline-danger p-1 px-2"><i class="mdi mdi-delete"></i> Delete</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-danger py-4">No tasks found. Please create one.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="mt-4">
                    <?php echo e($tasks->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sigmaticsoft\sigmaticsoft\src\resources\views/admin_portal/tasks/index.blade.php ENDPATH**/ ?>