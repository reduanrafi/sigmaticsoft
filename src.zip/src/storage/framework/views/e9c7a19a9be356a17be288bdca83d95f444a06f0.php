<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Client Details -->
    <div class="col-md-5 grid-margin stretch-card">
        <div class="card rounded">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="card-title font-weight-bold mb-0">Client Profile Details</h4>
                    <a href="<?php echo e(route('clients.index')); ?>" class="btn btn-outline-secondary btn-sm"><i class="mdi mdi-arrow-left"></i> Back</a>
                </div>

                <ul class="list-group list-group-flush">
                    <li class="list-group-item py-3">
                        <small class="text-muted d-block">Company Name</small>
                        <span class="font-weight-bold text-dark fs-15"><?php echo e($client->company_name); ?></span>
                    </li>
                    <li class="list-group-item py-3">
                        <small class="text-muted d-block">Primary Contact Person</small>
                        <span class="font-weight-bold text-dark"><?php echo e($client->name); ?></span>
                    </li>
                    <li class="list-group-item py-3">
                        <small class="text-muted d-block">Email Address</small>
                        <span class="text-dark"><?php echo e($client->email ?? 'N/A'); ?></span>
                    </li>
                    <li class="list-group-item py-3">
                        <small class="text-muted d-block">Phone Number</small>
                        <span class="text-dark"><?php echo e($client->phone ?? 'N/A'); ?></span>
                        <?php if($client->alternate_phone): ?>
                            <span class="text-muted">/ <?php echo e($client->alternate_phone); ?></span>
                        <?php endif; ?>
                    </li>
                    <li class="list-group-item py-3">
                        <small class="text-muted d-block">Office Address</small>
                        <span class="text-dark"><?php echo e($client->address ?? 'N/A'); ?></span>
                    </li>
                    <li class="list-group-item py-3">
                        <small class="text-muted d-block">Status</small>
                        <span class="badge badge-<?php echo e($client->status === 'active' ? 'success' : 'danger'); ?>"><?php echo e(ucfirst($client->status)); ?></span>
                    </li>
                    <?php if($client->notes): ?>
                        <li class="list-group-item py-3">
                            <small class="text-muted d-block">Internal Notes</small>
                            <p class="text-muted mb-0" style="white-space: pre-line;"><?php echo e($client->notes); ?></p>
                        </li>
                    <?php endif; ?>
                </ul>

                <div class="text-center mt-4">
                    <a href="<?php echo e(route('clients.edit', $client->id)); ?>" class="btn btn-gradient-primary text-white w-100"><i class="mdi mdi-table-edit"></i> Edit Profile</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Client Access Logins & Projects -->
    <div class="col-md-7">
        <!-- Login User Accounts -->
        <div class="card rounded mb-4">
            <div class="card-body">
                <h4 class="card-title font-weight-bold mb-3">Portal Login Accounts</h4>
                <div class="table-responsive mb-4">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Created At</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $client->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($u->name); ?></td>
                                    <td><?php echo e($u->email); ?></td>
                                    <td><?php echo e($u->created_at->format('d M, Y')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3" class="text-center text-warning py-3">No login accounts associated with this client. Please create one below.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Create Login User Form -->
                <h5 class="font-weight-bold mb-3 text-success">Create Portal Access Credentials</h5>
                <form action="<?php echo e(route('clients.users.store', $client->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="user_name">Full Name</label>
                        <input type="text" name="name" id="user_name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required placeholder="e.g. John Doe (Portal User)" value="<?php echo e(old('name')); ?>">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="user_email">Email Address (Username)</label>
                        <input type="email" name="email" id="user_email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required placeholder="e.g. client@company.com" value="<?php echo e(old('email')); ?>">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label for="password">Password</label>
                            <input type="password" name="password" id="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required placeholder="Min 8 characters">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 form-group">
                            <label for="password_confirmation">Confirm Password</label>
                            <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" required placeholder="Repeat password">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-gradient-success text-white w-100"><i class="mdi mdi-key-plus"></i> Generate Login Credentials</button>
                </form>
            </div>
        </div>

        <!-- Projects List -->
        <div class="card rounded">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="card-title font-weight-bold mb-0">Client Projects</h4>
                    <a href="<?php echo e(route('projects.create', ['client_id' => $client->id])); ?>" class="btn btn-outline-success btn-sm"><i class="mdi mdi-plus"></i> Add Project</a>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Code</th>
                                <th>Project Name</th>
                                <th>Progress</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $client->projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><code><?php echo e($proj->project_code); ?></code></td>
                                    <td><strong><a href="<?php echo e(route('projects.show', $proj->id)); ?>"><?php echo e($proj->name); ?></a></strong></td>
                                    <td>
                                        <div class="progress" style="height: 10px;">
                                            <div class="progress-bar bg-gradient-success" role="progressbar" style="width: <?php echo e($proj->progress); ?>%;" aria-valuenow="<?php echo e($proj->progress); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <small class="text-muted d-block mt-1"><?php echo e($proj->progress); ?>% complete</small>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?php echo e($proj->status === 'active' ? 'success' : ($proj->status === 'completed' ? 'primary' : 'secondary')); ?>">
                                            <?php echo e(ucfirst(str_replace('_', ' ', $proj->status))); ?>

                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" class="text-center text-muted py-3">No projects registered for this client.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sigmaticsoft\sigmaticsoft\src\resources\views/admin_portal/clients/show.blade.php ENDPATH**/ ?>