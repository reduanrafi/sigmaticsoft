<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card rounded">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="card-title font-weight-bold mb-0">Client Requests & Issues</h4>
                </div>

                <!-- Filters -->
                <form action="<?php echo e(route('requests.index')); ?>" method="GET" class="mb-4">
                    <div class="row">
                        <div class="col-md-4 mb-2">
                            <input type="text" name="search" class="form-control" placeholder="Search request title" value="<?php echo e(request('search')); ?>">
                        </div>
                        <div class="col-md-3 mb-2">
                            <select name="client_id" class="form-control">
                                <option value="">Filter by Client</option>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($c->id); ?>" <?php echo e(request('client_id') == $c->id ? 'selected' : ''); ?>><?php echo e($c->company_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-3 mb-2">
                            <select name="status" class="form-control">
                                <option value="">Filter by Status</option>
                                <option value="submitted" <?php echo e(request('status') === 'submitted' ? 'selected' : ''); ?>>Submitted</option>
                                <option value="under_review" <?php echo e(request('status') === 'under_review' ? 'selected' : ''); ?>>Under Review</option>
                                <option value="accepted" <?php echo e(request('status') === 'accepted' ? 'selected' : ''); ?>>Accepted</option>
                                <option value="rejected" <?php echo e(request('status') === 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                                <option value="converted" <?php echo e(request('status') === 'converted' ? 'selected' : ''); ?>>Converted to Task</option>
                                <option value="closed" <?php echo e(request('status') === 'closed' ? 'selected' : ''); ?>>Closed</option>
                            </select>
                        </div>
                        <div class="col-md-2 mb-2">
                            <button type="submit" class="btn btn-gradient-primary text-white w-100">Filter</button>
                        </div>
                    </div>
                </form>

                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Client Company</th>
                                <th>Project</th>
                                <th>Request Title</th>
                                <th>Type</th>
                                <th>Priority</th>
                                <th>Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><code>#<?php echo e($req->id); ?></code></td>
                                    <td><?php echo e($req->client->company_name); ?></td>
                                    <td><?php echo e($req->project->name); ?></td>
                                    <td><strong><a href="<?php echo e(route('requests.show', $req->id)); ?>"><?php echo e(Str::limit($req->title, 40)); ?></a></strong></td>
                                    <td><span class="text-capitalize"><?php echo e($req->type); ?></span></td>
                                    <td>
                                        <span class="badge badge-<?php echo e($req->priority === 'critical' ? 'danger' : ($req->priority === 'high' ? 'warning' : ($req->priority === 'medium' ? 'info' : 'secondary'))); ?>">
                                            <?php echo e(ucfirst($req->priority)); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?php echo e($req->status === 'submitted' ? 'warning' : ($req->status === 'converted' ? 'success' : ($req->status === 'rejected' ? 'danger' : 'secondary'))); ?>">
                                            <?php echo e(ucfirst(str_replace('_', ' ', $req->status))); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <div class="d-flex justify-content-center">
                                            <a href="<?php echo e(route('requests.show', $req->id)); ?>" class="btn btn-sm btn-outline-info p-1 px-2 mr-2"><i class="mdi mdi-eye"></i> View</a>
                                            <?php if($req->status === 'converted' && $req->convertedTask): ?>
                                                <a href="<?php echo e(route('tasks.show', $req->converted_task_id)); ?>" class="btn btn-sm btn-outline-success p-1 px-2" title="Go to Task"><i class="mdi mdi-link"></i> Task</a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-danger py-4">No client requests found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="mt-4">
                    <?php echo e($requests->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sigmaticsoft\sigmaticsoft\src\resources\views/admin_portal/requests/index.blade.php ENDPATH**/ ?>