<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 grid-margin">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4 class="font-weight-bold mb-0">Kanban Task Board</h4>
            <div>
                <a href="<?php echo e(route('tasks.index')); ?>" class="btn btn-gradient-info text-white btn-sm mr-2"><i class="mdi mdi-format-list-bulleted"></i> Tasks List</a>
                <a href="<?php echo e(route('tasks.create')); ?>" class="btn btn-gradient-success text-white btn-sm"><i class="mdi mdi-plus"></i> Create Task</a>
            </div>
        </div>

        <!-- Project Filter -->
        <form action="<?php echo e(route('tasks.board')); ?>" method="GET" class="mb-4 bg-white p-3 rounded shadow-sm">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <select name="project_id" class="form-control" onchange="this.form.submit()">
                        <option value="">All Projects</option>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>" <?php echo e($projectId == $p->id ? 'selected' : ''); ?>><?php echo e($p->name); ?> (<?php echo e($p->client->company_name); ?>)</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-gradient-primary text-white w-100">Filter Board</button>
                </div>
            </div>
        </form>

        <!-- Board Grid -->
        <div class="row flex-row flex-nowrap" style="overflow-x: auto; padding-bottom: 20px;">
            <?php
                $statusColors = [
                    'backlog' => 'secondary',
                    'accepted' => 'info',
                    'in_progress' => 'primary',
                    'review' => 'warning',
                    'client_review' => 'dark',
                    'completed' => 'success'
                ];
                $statusLabels = [
                    'backlog' => 'Backlog',
                    'accepted' => 'Accepted',
                    'in_progress' => 'In Progress',
                    'review' => 'Review',
                    'client_review' => 'Client Review',
                    'completed' => 'Completed'
                ];
            ?>

            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statusKey => $taskList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-4 col-lg-3 flex-shrink-0" style="width: 280px; min-height: 500px;">
                    <div class="card bg-light border-top border-3 rounded p-2" style="border-top-color: var(--<?php echo e($statusColors[$statusKey] === 'secondary' ? 'gray' : ($statusColors[$statusKey] === 'info' ? 'cyan' : ($statusColors[$statusKey] === 'primary' ? 'blue' : ($statusColors[$statusKey] === 'warning' ? 'yellow' : ($statusColors[$statusKey] === 'dark' ? 'indigo' : 'green'))))); ?>) !important;">
                        <div class="d-flex justify-content-between align-items-center mb-3 px-2">
                            <h6 class="font-weight-bold text-dark mb-0"><?php echo e($statusLabels[$statusKey]); ?></h6>
                            <span class="badge badge-<?php echo e($statusColors[$statusKey]); ?>"><?php echo e(count($taskList)); ?></span>
                        </div>

                        <div class="kanban-cards-wrapper" style="max-height: 600px; overflow-y: auto;">
                            <?php $__empty_1 = true; $__currentLoopData = $taskList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="card mb-3 p-3 bg-white shadow-sm border rounded">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <code style="font-size: 11px;"><?php echo e($task->task_code); ?></code>
                                        <span class="badge badge-<?php echo e($task->priority === 'critical' ? 'danger' : ($task->priority === 'high' ? 'warning' : 'secondary')); ?>" style="font-size: 9px;">
                                            <?php echo e(ucfirst($task->priority)); ?>

                                        </span>
                                    </div>
                                    <h6 class="font-weight-bold text-dark mb-1" style="font-size: 13px;">
                                        <a href="<?php echo e(route('tasks.show', $task->id)); ?>" class="text-dark"><?php echo e($task->title); ?></a>
                                    </h6>
                                    <p class="text-muted mb-3" style="font-size: 11px; line-height: 1.2;">
                                        Project: <?php echo e($task->project->name); ?>

                                    </p>

                                    <div class="d-flex justify-content-between align-items-center">
                                        <small class="text-muted" style="font-size: 10px;">
                                            Assignee: <strong><?php echo e($task->assignee->name ?? 'Unassigned'); ?></strong>
                                        </small>
                                        
                                        <!-- Quick Status Change Form Dropdown -->
                                        <form action="<?php echo e(route('tasks.update-status')); ?>" method="POST" class="m-0">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="task_id" value="<?php echo e($task->id); ?>">
                                            <select name="status" class="form-control form-control-sm border-0 bg-light p-1" style="font-size: 10px; height: auto;" onchange="this.form.submit()">
                                                <?php $__currentLoopData = $statusLabels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($k); ?>" <?php echo e($task->status === $k ? 'selected' : ''); ?>>Move to <?php echo e($label); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="text-center text-muted py-4" style="font-size: 11px;">
                                    Empty column
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sigmaticsoft\sigmaticsoft\src\resources\views/admin_portal/tasks/board.blade.php ENDPATH**/ ?>