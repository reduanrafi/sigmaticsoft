<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-10 grid-margin stretch-card mx-auto">
        <div class="card rounded">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="card-title font-weight-bold mb-0">Your Support Requests</h4>
                    <a href="<?php echo e(route('client.requests.create')); ?>" class="btn btn-gradient-blue text-white btn-sm"><i class="mdi mdi-plus"></i> Submit Request</a>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Project Name</th>
                                <th>Request Title</th>
                                <th>Type</th>
                                <th>Priority</th>
                                <th>Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($req->created_at->format('d M, Y')); ?></td>
                                    <td><?php echo e($req->project->name); ?></td>
                                    <td><strong><a href="<?php echo e(route('client.requests.show', $req->id)); ?>"><?php echo e(Str::limit($req->title, 40)); ?></a></strong></td>
                                    <td><span class="text-capitalize"><?php echo e($req->type); ?></span></td>
                                    <td>
                                        <span class="badge badge-<?php echo e($req->priority === 'critical' ? 'danger' : ($req->priority === 'high' ? 'warning' : 'secondary')); ?> text-capitalize">
                                            <?php echo e($req->priority); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?php echo e($req->status === 'submitted' ? 'warning' : ($req->status === 'converted' ? 'success' : ($req->status === 'rejected' ? 'danger' : 'secondary'))); ?> text-capitalize">
                                            <?php echo e(str_replace('_', ' ', $req->status)); ?>

                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <div class="d-flex justify-content-center">
                                            <a href="<?php echo e(route('client.requests.show', $req->id)); ?>" class="btn btn-sm btn-outline-info p-1 px-3 mr-2"><i class="mdi mdi-eye"></i> View</a>
                                            <?php if($req->status === 'submitted'): ?>
                                                <a href="<?php echo e(route('client.requests.edit', $req->id)); ?>" class="btn btn-sm btn-outline-primary p-1 px-3"><i class="mdi mdi-pencil"></i> Edit</a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">No support requests submitted yet.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="mt-4">
                    <?php echo e($requests->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal_client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sigmaticsoft\sigmaticsoft\src\resources\views/client_portal/requests/index.blade.php ENDPATH**/ ?>