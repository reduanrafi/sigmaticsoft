<footer class="footer">
    <div class="d-sm-flex justify-content-center justify-content-sm-between">
        <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright ©
            <?php echo now()?>. <a href="https://www.bootstrapdash.com/" target="_blank">Sigmatic Soft</a> All rights
            reserved.</span>
    </div>
</footer>

<!-- ./wrapper -->