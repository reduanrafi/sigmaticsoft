
<?php $__env->startSection('content'); ?>
    <main class="hero_section" id="canvas_container">
        <div class="container">
            <div class="row">
                <div class="col-md-12 hero_text">
                    <h3>Website Templates, Plugins, and Graphics Digital Marketplace</h3>
                    <h4>Best place to buy and sell digital products.
                    </h4>
                    <div class="input-group">
                        <input type="search" class="form-control" placeholder="Search like 'Wordpress'">
                        <button class="btn bg-light" type="button"><i class="fa-solid fa-magnifying-glass"></i></button>
                    </div>
                </div>
            </div>
            <div class="row row-cols-2 row-cols-lg-5 g-2 g-lg-3">
                <?php for($i = 0; $i < 5; $i++): ?>
                    <div class="col">
                        <div class="hero_service_box">
                            <a href="#">
                                <img src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" alt="">
                                <p>Laravel</p>
                            </a>

                        </div>
                    </div>
                <?php endfor; ?>
            </div>
        </div>
    </main>
    <?php echo $__env->make('website.pages.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('website.pages.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\sigmatic-soft\src\resources\views/website/index.blade.php ENDPATH**/ ?>