<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous">
</script>
<!-- <script src="<?php echo e(asset('assets/website/js/app.js')); ?>"></script> --><?php /**PATH E:\xampp\htdocs\sigmatic-soft\src\resources\views/website/layouts/footerscript.blade.php ENDPATH**/ ?>