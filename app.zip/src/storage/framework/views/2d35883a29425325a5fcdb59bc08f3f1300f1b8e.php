<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
      integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="<?php echo e(asset('assets/website/css/font-awesome/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/website/css/font-awesome/css/fontawesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/website/css/style.css')); ?>"><?php /**PATH E:\xampp\htdocs\sigmatic-soft\src\resources\views/website/layouts/headerStyle.blade.php ENDPATH**/ ?>