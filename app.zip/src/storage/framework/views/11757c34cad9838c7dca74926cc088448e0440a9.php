<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e('Sigmatic Soft'); ?></title>
    <link rel="shortcut icon" href="images/logo/logo.png" type="image/x-icon">
    <?php echo $__env->make('website.layouts.headerStyle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('extra-css'); ?>
</head>
<?php /**PATH E:\xampp\htdocs\sigmatic-soft\src\resources\views/website/layouts/header.blade.php ENDPATH**/ ?>